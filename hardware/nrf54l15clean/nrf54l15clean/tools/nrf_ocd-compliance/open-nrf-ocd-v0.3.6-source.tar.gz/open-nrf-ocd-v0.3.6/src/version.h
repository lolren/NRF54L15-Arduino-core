#ifndef NRF_OCD_VERSION
#define NRF_OCD_VERSION "0.3.6"
#endif
