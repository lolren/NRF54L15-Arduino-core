# Source Provenance

The `v0.3.3` release executable source baseline is Git commit
`9e2ce3a1ba480c43cbb5f6b43a3d0acc47d83c92`.

The compliance source archive distributed beside the existing `v0.3.3` Linux
x86-64 binaries applies redistribution-only metadata to that baseline:

- project and component license texts
- retained pyOCD copyright and Apache-2.0 notices
- prominent adaptation notices in the four pyOCD-derived C files
- third-party and LGPL distribution guidance
- removal of the unrelated stale `build_win` output

Those changes do not alter executable C statements. They make the corresponding
source self-describing without moving or rewriting the published `v0.3.3` tag.
