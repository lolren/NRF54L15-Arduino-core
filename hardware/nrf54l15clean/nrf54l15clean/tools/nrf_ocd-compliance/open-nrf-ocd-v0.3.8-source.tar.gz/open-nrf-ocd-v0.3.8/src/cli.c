/* cli.c - command-line interface.
 *
 * Layout:
 *   nrf_ocd list                       - list probes
 *   nrf_ocd info [-t target] [-u uid]  - show target info
 *   nrf_ocd load [-t target] [-u uid] [-e chip|auto|none] [--auto-unlock]
 *                [-R] [--no-reset] [--verify|--no-verify] [--halt]
 *                <file>...
 *   nrf_ocd erase [-t target] [-u uid]
 *   nrf_ocd reset [-t target] [-u uid] [-M halt|default]
 *   nrf_ocd commander [-t target] [-u uid] [-f freq]
 *   nrf_ocd read [-t target] [-u uid] <addr> [count]
 *   nrf_ocd write [-t target] [-u uid] <addr> <hex>
 *
 * Global options (-t, -u, -f, -v, -q) are accepted anywhere before
 * the first positional argument; subcommand-specific options
 * (-e, --auto-unlock, -R, etc.) are also accepted at the global
 * position for ergonomic compatibility with pyOCD. The pyOCD-style
 * invocation:
 *
 *   nrf_ocd -t nrf54l15 -u 761FDE87 --auto-unlock -e chip -f file.hex -R
 *
 * just works.
 */
#include "cli.h"
#include "commander.h"
#include "elf.h"
#include "flash.h"
#include "hex.h"
#include "log.h"
#include "util.h"
#include "nrf_ocd.h"
#include "probe.h"
#include "target.h"
#include "util.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ----- helpers ------------------------------------------------------------ */
static int parse_int(const char *s, int dflt) {
    if (!s) return dflt;
    if (nrf_ocd_strncasecmp(s, "0x", 2) == 0) return (int)strtoul(s + 2, NULL, 16);
    if (s[0] == '0' && s[1] != '\0')           return (int)strtoul(s + 1, NULL, 8);
    return (int)strtoul(s, NULL, 10);
}

static uint32_t parse_u32(const char *s, uint32_t dflt) {
    if (!s) return dflt;
    if (nrf_ocd_strncasecmp(s, "0x", 2) == 0) return (uint32_t)strtoul(s + 2, NULL, 16);
    return (uint32_t)strtoul(s, NULL, 0);
}

/* ----- cmd: list ---------------------------------------------------------- */
static int cmd_list(void) {
    probe_info_t probes[32];
    size_t n = 0;
    nrf_ocd_status_t st = probe_list(probes, 32, &n);
    if (st != NRF_OCD_OK) {
        LOG_ERROR("probe_list failed: %s", nrf_ocd_strerror(st));
        return 1;
    }
    if (n == 0) {
        LOG_WARNING("No CMSIS-DAP probes found");
        return 0;
    }
    printf("  #   Probe/Board                                          Unique ID    Target\n");
    printf("--------------------------------------------------------------------------------\n");
    for (size_t i = 0; i < n; i++) {
        printf("  %-3zu %-50s %-12s %s\n",
               i, probes[i].product, probes[i].serial,
               target_type_name(target_type_from_onboard_probe(
                   probes[i].vendor_id, probes[i].product_id)));
    }
    return 0;
}

/* ----- shared context ----------------------------------------------------- */
typedef struct {
    target_type_t   target;
    char            uid[64];
    unsigned        index;
    int             freq_khz;
    flash_options_t flash_opts;
    bool            auto_unlock;
    bool            no_reset;
    bool            reset_after;
    bool            halt;
    const char     *legacy_file;
} cli_ctx_t;

static void cli_ctx_init(cli_ctx_t *c) {
    memset(c, 0, sizeof(*c));
    c->target  = TARGET_NRF54L15;
    c->freq_khz = 1000;
    c->flash_opts.erase  = FLASH_ERASE_NONE;
    c->flash_opts.verify = true;
}

static bool open_target_retryable(nrf_ocd_status_t st) {
    return st == NRF_OCD_ERR_IO ||
           st == NRF_OCD_ERR_TIMEOUT ||
           st == NRF_OCD_ERR_PROBE_IO ||
           st == NRF_OCD_ERR_PROBE_OPEN ||
           st == NRF_OCD_ERR_PROTOCOL ||
           st == NRF_OCD_ERR_FAULT;
}

static nrf_ocd_status_t open_target_once(cli_ctx_t *ctx, target_t *t) {
    hid_device_t *dev = NULL;
    probe_info_t  info;
    memset(&info, 0, sizeof(info));
    nrf_ocd_status_t st = probe_open(&info, &dev, ctx->uid[0] ? ctx->uid : NULL, ctx->index);
    if (st != NRF_OCD_OK) {
        LOG_ERROR("Could not open probe: %s", nrf_ocd_strerror(st));
        return st;
    }
    printf("  Probe: %s [%s] (%s) at %s\n",
             info.product, info.serial, info.manufacturer, info.path);
    if (!target_matches_onboard_probe(ctx->target, info.vendor_id,
                                      info.product_id)) {
        target_type_t onboard = target_type_from_onboard_probe(
            info.vendor_id, info.product_id);
        LOG_ERROR("Selected target %s does not match the onboard %s probe "
                  "(USB %04x:%04x); select the matching board before upload",
                  target_type_name(ctx->target), target_type_name(onboard),
                  info.vendor_id, info.product_id);
        hid_close(dev);
        return NRF_OCD_ERR_INVALID_ARG;
    }
    st = target_open(t, dev, ctx->target);
    if (st != NRF_OCD_OK) {
        hid_close(dev);
        return st;
    }
    t->allow_mass_erase = ctx->auto_unlock ||
                          ctx->flash_opts.erase == FLASH_ERASE_CHIP ||
                          ctx->flash_opts.erase == FLASH_ERASE_AUTO;
    st = target_init(t);
    if (st != NRF_OCD_OK) {
        LOG_ERROR("target_init failed: %s", nrf_ocd_strerror(st));
        target_close(t);
        return st;
    }
    if (t->ops && t->ops->read_part_info) {
        (void)t->ops->read_part_info(t);
    }
    return NRF_OCD_OK;
}

static nrf_ocd_status_t open_target(cli_ctx_t *ctx, target_t *t) {
    nrf_ocd_status_t st = NRF_OCD_ERR_GENERIC;
    for (int attempt = 0; attempt < 3; attempt++) {
        st = open_target_once(ctx, t);
        if (st == NRF_OCD_OK) return st;
        if (!open_target_retryable(st) || attempt == 2) break;
        LOG_WARNING("Probe/target handshake failed (%s); retrying",
                    nrf_ocd_strerror(st));
        nrf_ocd_sleep_ms((uint32_t)(250 * (attempt + 1)));
    }
    return st;
}

/* ----- cmd: info --------------------------------------------------------- */
static int cmd_info(cli_ctx_t *ctx) {
    target_t t;
    nrf_ocd_status_t st = open_target(ctx, &t);
    if (st != NRF_OCD_OK) return 1;
    target_close(&t);
    return 0;
}

/* ----- cmd: load (program flash) ----------------------------------------- */
static int cmd_load(cli_ctx_t *ctx, int argc, char **argv) {
    if (argc < 1) {
        LOG_ERROR("Usage: nrf_ocd load <file>...");
        return 1;
    }
    target_t t;
    nrf_ocd_status_t st = open_target(ctx, &t);
    if (st != NRF_OCD_OK) return 1;

    hex_image_t img;
    hex_image_init(&img);
    for (int i = 0; i < argc; i++) {
        const char *path = argv[i];
        if (nrf_ocd_str_endswith(path, ".hex") || nrf_ocd_str_endswith(path, ".ihx")) {
            st = hex_image_load(&img, path);
        } else if (nrf_ocd_str_endswith(path, ".elf")) {
            elf_info_t info;
            st = elf_load(path, &img, &info);
            if (st == NRF_OCD_OK) {
                LOG_INFO("ELF entry point: 0x%08x", info.entry);
            }
        } else {
            LOG_ERROR("Unknown file format: %s", path);
            st = NRF_OCD_ERR_FILE_FORMAT;
        }
        if (st != NRF_OCD_OK) {
            LOG_ERROR("Failed to load %s: %s", path, nrf_ocd_strerror(st));
            hex_image_free(&img);
            target_close(&t);
            return 1;
        }
    }
    if (img.count == 0) {
        LOG_ERROR("No data to program");
        hex_image_free(&img);
        target_close(&t);
        return 1;
    }
    size_t total = 0;
    hex_image_total_size(&img, &total);
    printf("  Loaded %zu KB (%zu segment(s))\n", total / 1024, img.count);

    st = flash_write_image(&t, &img, &ctx->flash_opts);
    hex_image_free(&img);
    if (st != NRF_OCD_OK) {
        LOG_ERROR("Flash programming failed: %s", nrf_ocd_strerror(st));
        target_close(&t);
        return 1;
    }
    bool reset_succeeded = false;
    if (ctx->reset_after && !ctx->no_reset) {
        if (t.ops && t.ops->reset) {
            st = t.ops->reset(&t, TARGET_RESET_DEFAULT);
            if (st != NRF_OCD_OK) {
                LOG_WARNING("Reset failed: %s", nrf_ocd_strerror(st));
            } else {
                reset_succeeded = true;
            }
        }
    }
    if (reset_succeeded) {
        target_close_after_reset(&t);
    } else {
        target_close(&t);
    }
    printf("  Upload complete\n");
    return 0;
}

/* ----- cmd: erase -------------------------------------------------------- */
static int cmd_erase(cli_ctx_t *ctx) {
    /* The erase command itself is explicit authorization to unlock by erase. */
    ctx->auto_unlock = true;
    target_t t;
    nrf_ocd_status_t st = open_target(ctx, &t);
    if (st != NRF_OCD_OK) return 1;
    st = t.mass_erased ? NRF_OCD_OK : flash_chip_erase(&t);
    if (st != NRF_OCD_OK) {
        LOG_ERROR("Erase failed: %s", nrf_ocd_strerror(st));
        target_close(&t);
        return 1;
    }
    printf("  Chip erase complete\n");
    target_close(&t);
    return 0;
}

/* ----- cmd: reset -------------------------------------------------------- */
static int cmd_reset(cli_ctx_t *ctx) {
    target_t t;
    nrf_ocd_status_t st = open_target(ctx, &t);
    if (st != NRF_OCD_OK) return 1;
    bool reset_succeeded = false;
    if (t.ops && t.ops->reset) {
        st = t.ops->reset(&t, ctx->halt ? TARGET_RESET_HALT : TARGET_RESET_DEFAULT);
        if (st != NRF_OCD_OK) {
            LOG_ERROR("Reset failed: %s", nrf_ocd_strerror(st));
            target_close(&t);
            return 1;
        }
        reset_succeeded = true;
    }
    if (reset_succeeded) {
        target_close_after_reset(&t);
    } else {
        target_close(&t);
    }
    printf("  Target reset\n");
    return 0;
}

/* ----- cmd: commander ---------------------------------------------------- */
static int cmd_commander(cli_ctx_t *ctx) {
    target_t t;
    nrf_ocd_status_t st = open_target(ctx, &t);
    if (st != NRF_OCD_OK) return 1;
    st = commander_run(&t);
    target_close(&t);
    return (st == NRF_OCD_OK) ? 0 : 1;
}

/* ----- cmd: read / write memory ------------------------------------------ */
static int cmd_read_mem(cli_ctx_t *ctx, int argc, char **argv) {
    if (argc < 1) {
        LOG_ERROR("Usage: nrf_ocd read <addr> [count]");
        return 1;
    }
    uint32_t addr = parse_u32(argv[0], 0);
    size_t count = argc > 1 ? (size_t)parse_int(argv[1], 16) : 16;
    target_t t;
    nrf_ocd_status_t st = open_target(ctx, &t);
    if (st != NRF_OCD_OK) return 1;
    uint8_t *buf = (uint8_t *)malloc(count);
    if (!buf) { target_close(&t); return 1; }
    st = target_mem_read(&t, addr, buf, count);
    if (st != NRF_OCD_OK) {
        LOG_ERROR("Memory read failed: %s", nrf_ocd_strerror(st));
        free(buf);
        target_close(&t);
        return 1;
    }
    nrf_ocd_hex_dump(buf, count, addr, stdout);
    free(buf);
    target_close(&t);
    return 0;
}

static int cmd_write_mem(cli_ctx_t *ctx, int argc, char **argv) {
    if (argc < 2) {
        LOG_ERROR("Usage: nrf_ocd write <addr> <hex>");
        return 1;
    }
    uint32_t addr = parse_u32(argv[0], 0);
    const char *hex = argv[1];
    size_t hlen = strlen(hex);
    if (hlen & 1) {
        LOG_ERROR("hex string must have even length");
        return 1;
    }
    size_t n = hlen / 2;
    uint8_t *buf = (uint8_t *)malloc(n);
    if (!buf) return 1;
    for (size_t i = 0; i < n; i++) {
        char tmp[3] = { hex[2*i], hex[2*i+1], 0 };
        buf[i] = (uint8_t)strtoul(tmp, NULL, 16);
    }
    target_t t;
    nrf_ocd_status_t st = open_target(ctx, &t);
    if (st != NRF_OCD_OK) { free(buf); return 1; }
    st = target_mem_write(&t, addr, buf, n);
    free(buf);
    if (st != NRF_OCD_OK) {
        LOG_ERROR("Memory write failed: %s", nrf_ocd_strerror(st));
        target_close(&t);
        return 1;
    }
    target_close(&t);
    return 0;
}

/* ----- usage ------------------------------------------------------------- */
static void print_usage(FILE *f) {
    fprintf(f,
        "Usage: nrf_ocd [options] <command> [args]\n"
        "\n"
        "Commands:\n"
        "  list                          List CMSIS-DAP probes\n"
        "  info                          Show target info (reads UICR)\n"
        "  load <file>...                Flash HEX/ELF file(s) to target\n"
        "  erase                         Mass erase the chip\n"
        "  reset                         Reset the target\n"
        "  commander                     Interactive terminal\n"
        "  read <addr> [count]           Read memory (default 16 bytes)\n"
        "  write <addr> <hex>            Write hex bytes to memory\n"
        "\n"
        "Options:\n"
        "  -p, --port <device>           Serial port device (e.g. /dev/ttyACM0 or COM1)\n"
    "  -u, --uid <serial>            Probe serial (e.g. 761FDE87)\n"
        "  -t, --target <name>           nrf54l15, nrf54lm20a\n"
        "      --index <n>               Probe index\n"
        "  -f, --frequency <khz>         SWD clock (default 1000)\n"
        "  -v, --verbose                 Verbose logging\n"
        "  -h, --help                    Show help\n"
        "\n"
        "Flash options (place before 'load' or globally):\n"
        "  -e, --erase <mode>            auto, chip, sector, none\n"
        "      --auto-unlock             Mass erase if locked\n"
        "  -R, --reset                   Reset after programming\n"
        "      --verify / --no-verify    Verify flash (default: on)\n"
        "      --halt                    Halt before programming\n"
        "\n"
        "Examples:\n"
        "  nrf_ocd list\n"
        "  nrf_ocd -t nrf54l15 -u 761FDE87 info\n"
        "  nrf_ocd -t nrf54l15 -u 761FDE87 read 0x00FFC31C 16\n"
        "  nrf_ocd -t nrf54l15 -u 761FDE87 write 0x20000000 DEADBEEF\n"
        "  nrf_ocd -t nrf54l15 -u 761FDE87 -e chip -R load firmware.hex\n"
        "  nrf_ocd -t nrf54lm20a -u 3377B9D6 -e chip -R load firmware.hex\n"
        "  nrf_ocd -t nrf54l15 -u 761FDE87 erase\n"
        "  nrf_ocd -t nrf54l15 -u 761FDE87 reset\n"
        "  nrf_ocd -t nrf54l15 -u 761FDE87 commander\n"
        "\n");
}

/* ----- argument parser --------------------------------------------------- */
static int apply_long_option(cli_ctx_t *ctx, int val, const char *arg) {
    switch (val) {
        case 'p': {
            char buf[64] = {0};
            if (port_to_serial(arg, buf, sizeof(buf))) {
                nrf_ocd_str_copy(ctx->uid, sizeof(ctx->uid), buf);
            } else {
                LOG_ERROR("Cannot determine probe serial from port %s", arg);
                return 1;
            }
            return 0;
        }
        case 'u': nrf_ocd_str_copy(ctx->uid, sizeof(ctx->uid), arg); return 0;
        case 't': {
            target_type_t ty = target_type_from_string(arg);
            if (ty == TARGET_UNKNOWN) {
                LOG_ERROR("Unknown target: %s", arg);
                return 1;
            }
            ctx->target = ty;
            return 0;
        }
        case 1001: ctx->index = (unsigned)parse_int(arg, 0); return 0;
        case 'f':
            if (arg && (nrf_ocd_str_endswith(arg, ".hex")
                     || nrf_ocd_str_endswith(arg, ".ihx")
                     || nrf_ocd_str_endswith(arg, ".elf")
                     || nrf_ocd_str_endswith(arg, ".bin"))) {
                /* pyOCD compatibility: -f may specify the input file. */
                ctx->legacy_file = arg;
                return 0;
            }
            ctx->freq_khz = parse_int(arg, 1000);
            return 0;
        case 'e':
            if (nrf_ocd_strcasecmp(arg, "auto") == 0)        ctx->flash_opts.erase = FLASH_ERASE_AUTO;
            else if (nrf_ocd_strcasecmp(arg, "chip") == 0)  ctx->flash_opts.erase = FLASH_ERASE_CHIP;
            else if (nrf_ocd_strcasecmp(arg, "sector") == 0) ctx->flash_opts.erase = FLASH_ERASE_SECTOR;
            else if (nrf_ocd_strcasecmp(arg, "none") == 0)  ctx->flash_opts.erase = FLASH_ERASE_NONE;
            else { LOG_ERROR("Unknown erase mode: %s", arg); return 1; }
            return 0;
        case 'R': ctx->reset_after = true; return 0;
        case 2001: ctx->auto_unlock = true; return 0;
        case 2002: ctx->no_reset = true; return 0;
        case 2003: ctx->flash_opts.verify = true; return 0;
        case 2004: ctx->flash_opts.verify = false; return 0;
        case 2005: ctx->halt = true; return 0;
        default:  return 1;
    }
}

typedef struct {
    const char *name;
    int value;
    bool requires_arg;
} cli_long_option_t;

static const cli_long_option_t cli_long_options[] = {
    {"uid",         'u',  true},
    {"port",        'p',  true},
    {"target",      't',  true},
    {"index",       1001, true},
    {"frequency",   'f',  true},
    {"verbose",     'v',  false},
    {"quiet",       'q',  false},
    {"help",        'h',  false},
    {"auto-unlock", 2001, false},
    {"reset",       'R',  false},
    {"no-reset",    2002, false},
    {"verify",      2003, false},
    {"no-verify",   2004, false},
    {"halt",        2005, false},
    {"erase",       'e',  true},
};

static int cli_option_index = 1;

static int apply_parser_option(cli_ctx_t *ctx, int value, const char *arg) {
    if (value == 'v') {
        log_level_t level = nrf_ocd_log_get_level();
        if (level < LOG_LEVEL_TRACE) nrf_ocd_log_set_level(level + 1);
        return 0;
    }
    if (value == 'q') {
        log_level_t level = nrf_ocd_log_get_level();
        if (level > LOG_LEVEL_ERROR) nrf_ocd_log_set_level(level - 1);
        return 0;
    }
    if (value == 'h') {
        print_usage(stdout);
        exit(0);
    }
    return apply_long_option(ctx, value, arg);
}

static const cli_long_option_t *find_long_option(const char *name, size_t len) {
    size_t count = sizeof(cli_long_options) / sizeof(cli_long_options[0]);
    for (size_t i = 0; i < count; i++) {
        if (strlen(cli_long_options[i].name) == len &&
            strncmp(cli_long_options[i].name, name, len) == 0) {
            return &cli_long_options[i];
        }
    }
    return NULL;
}

static bool short_option_requires_arg(int value) {
    return value == 'u' || value == 'p' || value == 't' ||
           value == 'f' || value == 'e';
}

static bool short_option_is_valid(int value) {
    return short_option_requires_arg(value) || value == 'v' || value == 'q' ||
           value == 'h' || value == 'R';
}

static int parse_opts(int argc, char **argv, cli_ctx_t *ctx) {
    int i = 1;
    while (i < argc) {
        const char *token = argv[i];
        if (strcmp(token, "--") == 0) {
            i++;
            break;
        }
        if (token[0] != '-' || token[1] == '\0') break;

        if (token[1] == '-') {
            const char *name = token + 2;
            const char *equals = strchr(name, '=');
            size_t name_len = equals ? (size_t)(equals - name) : strlen(name);
            const cli_long_option_t *option = find_long_option(name, name_len);
            if (!option) {
                LOG_ERROR("Unknown option: %s", token);
                return 1;
            }

            const char *arg = equals ? equals + 1 : NULL;
            if (option->requires_arg && !arg) {
                if (++i >= argc) {
                    LOG_ERROR("Option --%s requires an argument", option->name);
                    return 1;
                }
                arg = argv[i];
            } else if (!option->requires_arg && arg) {
                LOG_ERROR("Option --%s does not take an argument", option->name);
                return 1;
            }
            if (apply_parser_option(ctx, option->value, arg) != 0) return 1;
            i++;
            continue;
        }

        const char *shorts = token + 1;
        while (*shorts) {
            int value = (unsigned char)*shorts++;
            if (!short_option_is_valid(value)) {
                LOG_ERROR("Unknown option: -%c", value);
                return 1;
            }
            const char *arg = NULL;
            if (short_option_requires_arg(value)) {
                if (*shorts) {
                    arg = shorts;
                    shorts += strlen(shorts);
                } else {
                    if (++i >= argc) {
                        LOG_ERROR("Option -%c requires an argument", value);
                        return 1;
                    }
                    arg = argv[i];
                }
            }
            if (apply_parser_option(ctx, value, arg) != 0) return 1;
        }
        i++;
    }
    cli_option_index = i;
    return 0;
}

int cli_run(int argc, char **argv) {
    cli_ctx_t ctx;
    cli_ctx_init(&ctx);
    if (argc < 2) { print_usage(stderr); return 1; }
    if (parse_opts(argc, argv, &ctx) != 0) return 1;

    /* Whatever non-option args remain after parse_opts() are the
     * subcommand and its arguments. */
    if (cli_option_index >= argc) {
        if (ctx.legacy_file) {
            char *file_argv[1] = {(char *)ctx.legacy_file};
            return cmd_load(&ctx, 1, file_argv);
        }
        print_usage(stderr);
        return 1;
    }
    const char *cmd = argv[cli_option_index];
    int cmd_argc = argc - cli_option_index - 1;
    char **cmd_argv = argv + cli_option_index + 1;

    if (nrf_ocd_strcasecmp(cmd, "list") == 0) {
        return cmd_list();
    } else if (nrf_ocd_strcasecmp(cmd, "info") == 0) {
        return cmd_info(&ctx);
    } else if (nrf_ocd_strcasecmp(cmd, "load") == 0) {
        return cmd_load(&ctx, cmd_argc, cmd_argv);
    } else if (nrf_ocd_strcasecmp(cmd, "flash") == 0) {
        /* Alias for load. */
        return cmd_load(&ctx, cmd_argc, cmd_argv);
    } else if (nrf_ocd_strcasecmp(cmd, "erase") == 0) {
        return cmd_erase(&ctx);
    } else if (nrf_ocd_strcasecmp(cmd, "reset") == 0) {
        return cmd_reset(&ctx);
    } else if (nrf_ocd_strcasecmp(cmd, "commander") == 0
            || nrf_ocd_strcasecmp(cmd, "cmd") == 0) {
        return cmd_commander(&ctx);
    } else if (nrf_ocd_strcasecmp(cmd, "read") == 0) {
        return cmd_read_mem(&ctx, cmd_argc, cmd_argv);
    } else if (nrf_ocd_strcasecmp(cmd, "write") == 0) {
        return cmd_write_mem(&ctx, cmd_argc, cmd_argv);
    } else if (nrf_ocd_strcasecmp(cmd, "help") == 0
            || nrf_ocd_strcasecmp(cmd, "-h") == 0
            || nrf_ocd_strcasecmp(cmd, "--help") == 0) {
        print_usage(stdout);
        return 0;
    } else if (nrf_ocd_str_endswith(cmd, ".hex") || nrf_ocd_str_endswith(cmd, ".ihx")
            || nrf_ocd_str_endswith(cmd, ".elf") || nrf_ocd_str_endswith(cmd, ".bin")) {
        /* Bare filename - default to load. */
        return cmd_load(&ctx, cmd_argc + 1, argv + cli_option_index);
    } else {
        LOG_ERROR("Unknown command: %s", cmd);
        print_usage(stderr);
        return 1;
    }
}
